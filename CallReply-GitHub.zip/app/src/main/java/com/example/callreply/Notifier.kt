package com.example.callreply

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri

object Notifier {
    private const val CH = "wa_reply"

    /** يبني رابط wa.me من الرقم (يحوّل 01xxxx لـ 201xxxx بكود الدولة). */
    fun waLink(number: String, text: String, cc: String): String {
        var d = number.filter { it.isDigit() }
        if (!number.trim().startsWith("+")) {
            d = when {
                d.startsWith("00") -> d.drop(2)
                d.startsWith("0") -> cc + d.drop(1)
                else -> d
            }
        }
        return "https://wa.me/$d?text=" + Uri.encode(text)
    }

    fun post(ctx: Context, number: String, text: String, cc: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "ردود واتساب", NotificationManager.IMPORTANCE_HIGH)
        )
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(waLink(number, text, cc)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val id = normalize(number).hashCode()
        val pi = PendingIntent.getActivity(
            ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("ابعت واتساب لـ $number")
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}
